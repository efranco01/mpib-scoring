Thank you for using the testScoring script! GUI and more data analysis tools coming soon!

How to use:
1. Place the testScoring.exe in the same folder as the test files.
2. Run the testScoring.exe
3. The program will ask if you want to use default settings or override mode. With override mode, you can be more selective with the files you want to use (You can also change output file type and block type)
4. After running the program, you will find a new directory called "your directory name"_scores. This will contain all of the output files for tests in the directory.
5. Output files are in the form "directory name"_"test name".csv. If you chose a different output file type, it will be in that format.
